//
//  BookingTabCVCCollectionViewCell.swift
//  SpeakEasy-Consumer
//
//  Created by Admin on 03/09/2022.
//

import UIKit

class BookingTabCVCCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var lblOption: UILabel!
    @IBOutlet weak var viewSelectedTab: UIView!
    @IBOutlet weak var countMessage: UIView!
    
    func setData(data: TabBarOption) {
        self.lblOption.text = data.label
        if data.label == Strings.MESSAGES.text {
            self.countMessage.isHidden = false
        }else{
            self.countMessage.isHidden = true
        }
        switch data.isSelected {
        case true:
            self.lblOption.textColor = .white
        case false:
            self.lblOption.textColor = Global.APP_COLOR_DARK_GREY
        }
        
        self.viewSelectedTab.isHidden = !data.isSelected
    }


}
